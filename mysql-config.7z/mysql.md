```bash
Z:\Program Files\mysql-5.7.28-winx64\bin>mysqld -install
Service successfully installed.

Z:\Program Files\mysql-5.7.28-winx64\bin>mysqld --initialize

Z:\Program Files\mysql-5.7.28-winx64\bin>code ..\my.ini

Z:\Program Files\mysql-5.7.28-winx64\bin>net start mysql
MySQL 服务正在启动 .
MySQL 服务已经启动成功。


Z:\Program Files\mysql-5.7.28-winx64\bin>mysql -u root -p
Enter password: ************
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 2
Server version: 5.7.28

Copyright (c) 2000, 2019, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> ALTER USER 'root'@'localhost' IDENTIFIED BY '123';
Query OK, 0 rows affected (0.00 sec)

mysql> exit
Bye

Z:\Program Files\mysql-5.7.28-winx64\bin>
```

[下载链接](https://dev.mysql.com/downloads/mysql/5.7.html)

```my.ini
[mysqld]
basedir="Z:\Program Files\mysql-5.7.28-winx64"
datadir="Z:\Program Files\mysql-5.7.28-winx64\data"
port=3306
```

![随机生成的密码](password.png)